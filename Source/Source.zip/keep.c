#include <stdio.h>

int main(){
	while(1){
		sleep(30);
	}
	return 0;
}
