wget -4 https://github.com/shadowsocks/shadowsocks-libev/releases/download/v3.3.1/shadowsocks-libev-3.3.1.tar.gz
wget -4 https://github.com/xtaci/kcptun/releases/download/20190910/kcptun-linux-amd64-20190910.tar.gz
wget -4 https://www.silvester.org.uk/privoxy/Sources/3.0.28%20%28stable%29/privoxy-3.0.28-stable-src.tar.gz